// lib/services/repository_providers.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../model/section_data.dart';
import '../model/stage_master.dart';
import 'stage_repository.dart';
import 'learning_assembly_service.dart';
import 'progress_repository.dart';

// (중복 주의) 프로젝트에 이미 userIdProvider가 있으면 아래 줄은 삭제하고 그걸 import!
final userIdProvider = StateProvider<String?>((ref) => null);

// 마스터 프리로드 (stages/)
final allStageMastersProvider = FutureProvider<List<StageMaster>>((ref) async {
  return StageRepository.instance.getAllStagesOnce();
});

/// 공용 섹션(섹션 마스터 없이) 조립
final publicSectionsProvider = FutureProvider<List<SectionData>>((ref) async {
  // StageRepository 캐시 채우기 (선택)
  await StageRepository.instance.getAllStagesOnce();
  return LearningAssemblyService.instance.buildPublicSections();
});

/// (선택) 사용자 섹션: 필요 없으면 지우세요.
/// 진행 order 맵을 받아서 섹션을 조립하는 버전으로 교체해 둡니다.
final userSectionsByOrderProvider = FutureProvider.family<List<SectionData>, Map<String,int>>((ref, orderByStageId) async {
  await StageRepository.instance.getAllStagesOnce();
  return LearningAssemblyService.instance.buildUserSectionsByOrderMap(orderByStageId: orderByStageId);
});

/// 진행도 스트림 (Stage 단위)
final stageProgressStreamProvider =
StreamProvider.family<Map<String, dynamic>?, String>((ref, stageId) {
  final uid = ref.watch(userIdProvider);
  if (uid == null) return const Stream.empty();
  return ProgressRepository.instance.watchStageProgress(uid: uid, stageId: stageId);
});
