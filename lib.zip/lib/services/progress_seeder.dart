import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:readventure/services/stage_repository.dart';

class ProgressSeeder {
  static Future<void> seedUserProgressAfterTutorial(String uid) async {
    if (uid.isEmpty) throw ArgumentError('uid is empty');

    final db = FirebaseFirestore.instance;

    // 스테이지 목록은 기존 로직대로 가져오기
    final stages = await StageRepository.instance.getAllStagesOnce();

    // ❗ 체이닝으로 정확한 경로 지정
    final userDoc    = db.collection('users').doc(uid);
    final progressCol = userDoc.collection('progress');

    final batch = db.batch();

    // 유저 문서 보증
    batch.set(userDoc, {
      'createdAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    for (final stage in stages) {
      final stageId = (stage.id ?? '').toString(); // stageId → id로 변경
      if (stageId.isEmpty || stageId.contains('/')) continue; // '/' 포함 금지

      final progressDoc = progressCol.doc(stageId);
      batch.set(progressDoc, {
        'stageId': stageId,
        'status': 'locked',
        'achievement': 0,
        'activityCompleted': {
          'beforeReading': false,
          'duringReading': false,
          'afterReading': false,
        },
        'createdAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }

    await batch.commit();
  }
}
