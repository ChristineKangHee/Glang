// lib/services/firestore_paths.dart
class FsPaths {
  static String stages = 'stages'; // ✅ 마스터 경로 확정
  static String stageMaster = 'stages'; // ✅ stage_repository가 이걸 씁니다
  static String sectionMaster = 'section_master'; // 쓰지 않으면 지워도 됨

  static String user(String uid) => 'users/$uid';
  static String userProgressSections(String uid) =>
      'users/$uid/progress/sections'; // ✅ 새 진행 경로
  static String userSections(String uid) => 'users/$uid/sections'; // (미래 확장 시)
}
