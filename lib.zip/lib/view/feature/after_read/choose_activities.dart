/// File: choose_activities.dart
/// Purpose: 읽기 후 학습 선택 화면 (progress 문서의 arData에 따라 표시/계산)
/// Author: 강희 (수정됨)
/// Last Modified: 2025-08-14

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../model/stage_data.dart';
import '../../../theme/font.dart';
import '../../../viewmodel/custom_colors_provider.dart';
import '../../../viewmodel/custom_colors_provider.dart' as custom_colors_provider;
import '../../../viewmodel/section_provider.dart';
import '../../../viewmodel/user_service.dart';
import '../../components/alarm_dialog.dart';
import '../../components/custom_app_bar.dart';
import 'package:readventure/theme/theme.dart';
import '../../components/custom_button.dart';
import '../../home/stage_provider.dart';
import '../Result_Report.dart';

// Activities
import 'GA_03_01_change_ending/CE_main.dart';
import 'GA_03_02_content_summary/CS_learning.dart';
import 'GA_03_03_debate_activity/DA_learning.dart';
import 'GA_03_04_diagram/diagram_learning.dart';
import 'GA_03_05_writing_form/writing_form_main.dart';
import 'GA_03_08_paragraph_analysis/paragraph_analysis_main.dart';
import 'GA_03_09_review_writing/review_writing_main.dart';

/// 학습 활동 데이터 모델
class LearningActivity {
  final String title;
  final String time;
  final String xp;
  final int featureNumber;
  final bool isCompleted;

  const LearningActivity({
    required this.title,
    required this.time,
    required this.xp,
    required this.featureNumber,
    this.isCompleted = false,
  });

  LearningActivity copyWith({bool? isCompleted}) => LearningActivity(
    title: title,
    time: time,
    xp: xp,
    featureNumber: featureNumber,
    isCompleted: isCompleted ?? this.isCompleted,
  );
}

class LearningActivitiesPage extends ConsumerStatefulWidget {
  @override
  _LearningActivitiesPageState createState() => _LearningActivitiesPageState();
}

class _LearningActivitiesPageState extends ConsumerState<LearningActivitiesPage> {
  // 베이스 활동 목록(정적)
  static const List<LearningActivity> baseActivities = [
    LearningActivity(title: '결말 바꾸기', time: '20분', xp: '100xp', featureNumber: 1),
    LearningActivity(title: '요약', time: '10분', xp: '50xp', featureNumber: 2),
    LearningActivity(title: '토론', time: '25분', xp: '120xp', featureNumber: 3),
    LearningActivity(title: '다이어그램', time: '5분', xp: '10xp', featureNumber: 4),
    LearningActivity(title: '문장 구조', time: '5분', xp: '10xp', featureNumber: 5),
    LearningActivity(title: '에세이 작성', time: '15분', xp: '80xp', featureNumber: 6),
    LearningActivity(title: '형식 변환하기', time: '30분', xp: '150xp', featureNumber: 7),
    LearningActivity(title: '주제 추출', time: '5분', xp: '10xp', featureNumber: 8),
    LearningActivity(title: '자유 소감', time: '5분', xp: '10xp', featureNumber: 9),
  ];

  @override
  void initState() {
    super.initState();
    // 설명 팝업
    Future.microtask(_showExplanationPopup);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) Navigator.pop(context); // 팝업 닫기
    });
  }

  @override
  Widget build(BuildContext context) {
    final customColors = ref.watch(custom_colors_provider.customColorsProvider);
    final uid = ref.watch(userIdProvider);
    final stageId = ref.watch(selectedStageIdProvider);

    // 현재 선택된 스테이지의 정적 마스터/조립 데이터 (제목 등 표시용)
    final stage = ref.watch(currentStageProvider);

    if (uid == null || stageId == null) {
      return Scaffold(
        backgroundColor: customColors.neutral90,
        body: Center(child: Text("사용자 또는 스테이지 정보가 없습니다.", style: body_small(context))),
      );
    }
    if (stage == null) {
      return Scaffold(
        backgroundColor: customColors.neutral90,
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    // 진행(progress) 문서 스트림: features / featuresCompleted 는 여기서 읽음
    final progressDocStream = FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('progress')
        .doc(stageId)
        .snapshots();

    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: progressDocStream,
      builder: (context, snap) {
        if (!snap.hasData) {
          return Scaffold(
            backgroundColor: customColors.neutral90,
            body: const Center(child: CircularProgressIndicator()),
          );
        }

        final data = snap.data!.data() ?? {};
        final arRaw = (data['arData'] as Map<String, dynamic>?) ?? const {};
        final features = (arRaw['features'] as List?)?.map((e) => int.tryParse('$e') ?? e as int).toList() ?? (stage.arData?.features ?? const <int>[]);
        final fcRaw = (arRaw['featuresCompleted'] as Map?)?.cast<String, dynamic>() ?? (stage.arData?.featuresCompleted ?? const <String, bool>{});

        // 화면용 활동 목록 구성
        final Set<int> allowedSet = (features as List<int>).toSet();
        final availableActivities = baseActivities
            .where((a) => allowedSet.contains(a.featureNumber))
            .map((a) => a.copyWith(isCompleted: (fcRaw['${a.featureNumber}'] == true)))
            .toList();

        // 진행/XP 계산
        final completedCount = availableActivities.where((a) => a.isCompleted).length;
        final totalXP = availableActivities
            .where((a) => a.isCompleted)
            .map((a) => int.parse(a.xp.replaceAll('xp', '')))
            .fold(0, (prev, e) => prev + e);
        final totalPossibleXP = availableActivities
            .map((a) => int.parse(a.xp.replaceAll('xp', '')))
            .fold(0, (prev, e) => prev + e);

        return Scaffold(
          backgroundColor: customColors.neutral90,
          appBar: CustomAppBar_2depth_6(
            title: '미션 선택',
            automaticallyImplyLeading: false,
            onIconPressed: () {
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
          ),
          body: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        _learningProgress(
                          completedCount,
                          totalXP,
                          totalPossibleXP,
                          customColors,
                          context,
                          availableActivities,
                        ),
                        const SizedBox(height: 20),
                        _activityList(context, customColors, stageId, availableActivities),
                      ],
                    ),
                  ),
                ),
              ),
              _resultButton(
                context: context,
                completedCount: completedCount,
                customColors: customColors,
                availableActivities: availableActivities,
                stageId: stageId,
                earnedXP: totalXP, // 이미 계산한 값 재사용
              ),
            ],
          ),
        );
      },
    );
  }

  // 진행 위젯
  Widget _learningProgress(
      int completedCount,
      int totalXP,
      int totalPossibleXP,
      CustomColors customColors,
      BuildContext context,
      List<LearningActivity> availableActivities,
      ) {
    final percent = availableActivities.isEmpty
        ? 0.0
        : completedCount / availableActivities.length;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: ShapeDecoration(
        color: customColors.neutral100,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      child: Row(
        children: [
          CircularPercentIndicator(
            radius: 40.0,
            lineWidth: 10.0,
            animation: true,
            percent: percent.clamp(0.0, 1.0),
            center: Text(
              '${(percent * 100).toStringAsFixed(0)}%',
              style: body_xsmall_semi(context).copyWith(color: customColors.neutral30),
            ),
            progressColor: customColors.primary,
            backgroundColor: customColors.neutral80 ?? Colors.grey,
            circularStrokeCap: CircularStrokeCap.round,
          ),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$totalXP/$totalPossibleXP xp',
                  style: heading_medium(context).copyWith(color: customColors.neutral30)),
              const SizedBox(height: 8),
              Text('$completedCount 미션 완료',
                  style: body_xsmall(context).copyWith(color: customColors.neutral60)),
            ],
          ),
        ],
      ),
    );
  }

  // 활동 리스트
  Widget _activityList(
      BuildContext context,
      CustomColors customColors,
      String stageId,
      List<LearningActivity> availableActivities,
      ) {
    final sorted = List<LearningActivity>.from(availableActivities)
      ..sort((a, b) => a.isCompleted ? 1 : -1);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: ShapeDecoration(
        color: customColors.neutral100,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('미션', style: body_small_semi(context)),
          const SizedBox(height: 20),
          ...sorted.map((activity) => Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: ShapeDecoration(
                color: activity.isCompleted ? customColors.neutral90 : customColors.neutral100,
                shape: RoundedRectangleBorder(
                  side: activity.isCompleted
                      ? BorderSide.none
                      : BorderSide(width: 1, color: customColors.neutral80 ?? const Color(0xFFCDCED3)),
                  borderRadius: BorderRadius.circular(18),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildActivityText(activity, customColors),
                  _buildActivityButton(context, activity, customColors, stageId),
                ],
              ),
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildActivityText(LearningActivity activity, CustomColors customColors) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(activity.title, style: body_small_semi(context).copyWith(color: customColors.neutral30)),
        const SizedBox(height: 8),
        if (!activity.isCompleted)
          Row(
            children: [
              Icon(Icons.timer, size: 16, color: customColors.neutral30),
              const SizedBox(width: 4),
              Text(activity.time, style: body_xsmall(context).copyWith(color: customColors.neutral30)),
              const SizedBox(width: 8),
              Icon(Icons.star, size: 16, color: customColors.neutral30),
              const SizedBox(width: 4),
              Text(activity.xp, style: body_xsmall(context).copyWith(color: customColors.neutral30)),
            ],
          )
        else
          Text('경험치 ${activity.xp} 획득!', style: body_xsmall(context).copyWith(color: customColors.primary)),
      ],
    );
  }

  Widget _buildActivityButton(
      BuildContext context,
      LearningActivity activity,
      CustomColors customColors,
      String stageId,
      ) {
    return ElevatedButton(
      onPressed: activity.isCompleted
          ? null
          : () async {
        // 각 미션 페이지로 이동
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => _getActivityPage(activity.title)),
        );
      },
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        backgroundColor: activity.isCompleted ? customColors.neutral80 : customColors.primary,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      child: Text(
        activity.isCompleted ? '미션완료' : '미션하기',
        style: body_xsmall_semi(context)
            .copyWith(color: activity.isCompleted ? customColors.neutral30 : customColors.neutral100),
      ),
    );
  }

  // 학습 활동에 맞는 페이지 반환
  Widget _getActivityPage(String title) {
    switch (title) {
      case '결말 바꾸기':
        return const SizedBox(); // ChangeEndingMain(); // 아직 미연결이면 비워둠
      case '요약':
        return CSLearning();
      case '토론':
        return DebatePage();
      case '다이어그램':
        return RootedTreeScreen();
      case '문장 구조':
        return WritingFormMain();
      case '에세이 작성':
        return const SizedBox(); // WritingEssayMain();
      case '형식 변환하기':
        return const SizedBox(); // FormatConversionMain();
      case '주제 추출':
        return ParagraphAnalysisMain();
      case '자유 소감':
        return ReviewWritingMain();
      default:
        return const SizedBox();
    }
  }

  // 제출 버튼
  Widget _resultButton({
    required BuildContext context,
    required int completedCount,
    required CustomColors customColors,
    required List<LearningActivity> availableActivities,
    required String stageId,
    required int earnedXP,
  }) {
    final allDone = availableActivities.isNotEmpty && completedCount == availableActivities.length;
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: const EdgeInsets.all(16.0),
      child: allDone
          ? ButtonPrimary(
        function: () async {
          await _onSubmit(stageId, earnedXP, customColors);
        },
        title: '결과 확인하기',
      )
          : ButtonPrimary20(
        function: () {
          debugPrint("결과 확인하기 (미완료)");
        },
        title: '결과 확인하기',
      ),
    );
  }

  // 결과 팝업
  void _showExplanationPopup() {
    final customColors = ref.read(custom_colors_provider.customColorsProvider);
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 44, vertical: 28),
            decoration: ShapeDecoration(
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: double.infinity,
                  child: Text(
                    '읽은 내용과 관련된\n미션을 해볼까요?',
                    textAlign: TextAlign.center,
                    style: body_large_semi(context).copyWith(color: customColors.neutral30),
                  ),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: 172,
                  height: 172,
                  child: Image.asset("assets/images/book_star.png"),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  child: Text(
                    '경험치를 채워 미션을 완료해보세요!',
                    textAlign: TextAlign.center,
                    style: body_small(context).copyWith(color: customColors.neutral60),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // 제출: afterReading 완료 + XP 반영 + 다음 스테이지 해금(조건부)
  Future<void> _onSubmit(String stageId, int earnedXP, CustomColors customColors) async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) {
      debugPrint("⚠️ 유저가 로그인되지 않음!");
      return;
    }

    // 1) afterReading 완료
    await completeActivityForStage(
      userId: userId,
      stageId: stageId,
      activityType: 'afterReading',
    );

    // 2) XP 누적
    final userRef = FirebaseFirestore.instance.collection('users').doc(userId);
    final currentTotalXP = ref.read(userXPProvider).value ?? 0;
    final newTotalXP = currentTotalXP + earnedXP;
    await userRef.update({'totalXP': newTotalXP});

    // 3) 다음 스테이지 해금 (현재가 completed 상태일 때만)
    await _maybeUnlockNextStage(userId, stageId);

    // 4) 섹션/홈 리프레시
    ref.invalidate(sectionProvider);

    // 5) 결과 다이얼로그 → 리포트
    showResultSaveDialog(
      context,
      customColors,
      "결과를 확인하시겠습니까?",
      "아니오",
      "예",
          (ctx) {
        Navigator.pushReplacement(
          ctx,
          MaterialPageRoute(builder: (ctx) => ResultReportPage(earnedXP: earnedXP)),
        );
      },
    );
  }

  Future<void> _maybeUnlockNextStage(String userId, String currentStageId) async {
    final nextId = _getNextStageId(currentStageId);
    if (nextId == null) return;

    final userDoc = FirebaseFirestore.instance.collection('users').doc(userId);
    final currentRef = userDoc.collection('progress').doc(currentStageId);
    final nextRef = userDoc.collection('progress').doc(nextId);

    await FirebaseFirestore.instance.runTransaction((tx) async {
      final currentSnap = await tx.get(currentRef);
      if (!currentSnap.exists) return;

      final statusStr = (currentSnap.data()?['status'] ?? 'locked').toString();
      if (statusStr != 'completed') return; // 아직 완료 아님

      final nextSnap = await tx.get(nextRef);
      if (!nextSnap.exists) return;

      final nextStatusStr = (nextSnap.data()?['status'] ?? 'locked').toString();
      if (nextStatusStr == 'locked') {
        tx.update(nextRef, {'status': 'inProgress'});
      }
    });

    // 섹션 완료에 따른 코스 승급 로직이 필요하면 여기서 추가(기존 if%4 == 0 로직 등)
  }

  String? _getNextStageId(String currentStageId) {
    final parts = currentStageId.split('_');
    if (parts.length != 2) return null;
    final number = int.tryParse(parts[1]);
    if (number == null) return null;
    final nextNumber = number + 1;
    return 'stage_${nextNumber.toString().padLeft(3, '0')}';
  }
}

/// --------- 미션 완료 처리 (featuresCompleted) 트랜잭션 버전 ---------
/// 개별 미션 완료를 다른 화면에서 호출할 수 있게 헬퍼로 유지.
/// StageData를 변경하지 않고 progress.arData.featuresCompleted 만 갱신.
Future<void> updateFeatureCompletion({
  required String stageId,
  required int featureNumber,
  required bool isCompleted,
}) async {
  final userId = FirebaseAuth.instance.currentUser?.uid;
  if (userId == null) {
    debugPrint("updateFeatureCompletion: userId is null");
    return;
  }

  final stageRef = FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection('progress')
      .doc(stageId);

  try {
    await FirebaseFirestore.instance.runTransaction((tx) async {
      final snap = await tx.get(stageRef);
      if (!snap.exists) return;

      final data = Map<String, dynamic>.from(snap.data()!);
      final ar = Map<String, dynamic>.from((data['arData'] ?? const {}));
      final fc = Map<String, dynamic>.from((ar['featuresCompleted'] ?? const {}));

      fc['$featureNumber'] = isCompleted;
      ar['featuresCompleted'] = fc;
      tx.update(stageRef, {'arData': ar});
    });

    // 사용자 지표 업데이트(원자 증가)
    final userRef = FirebaseFirestore.instance.collection('users').doc(userId);
    await userRef.update({'completedMissionCount': FieldValue.increment(1)});
  } catch (e, stack) {
    debugPrint("updateFeatureCompletion error: $e");
    debugPrint("$stack");
  }
}
